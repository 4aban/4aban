Markup language: 
None

Description:
Add a button to execute a calcul on the selection if possible.

Test it below:
100 + 20 - (30/10)

Install:
- Download the zip file
- Unzip it
- Merge the style.css with your current markItUp! style.css
- Merge the set.js with your current markItUp! set.js
- Place the icon in your markItUp! images folder