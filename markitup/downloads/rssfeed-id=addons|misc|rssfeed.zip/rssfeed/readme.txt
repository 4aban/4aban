Markup language: 
Misc

Description:
Add a button to load Rss Feeds via Ajax with a Php server-side script. You can configure the result to format it in whatever markup langage you want.

Install:
- Download the zip file
- Unzip it
- Merge the style.css with your current markItUp! style.css
- Merge the set.js with your current markItUp! set.js
- Place the icon in your markItUp! images folder
- Place Utils folder in your markItUp! folder