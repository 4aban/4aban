Markup language: 
CSS

Description:
A CSS editor set with Bold, Italic, Stroke through, Lowercase, Uppercase,
Left/Center/Right/Justify Alignment, Text indent, Letter spacing, Line height, 
Left/Top/Right/Bottom Padding and Margin, Background image and CSS file import.

Tips:
Alt+Padding button: Switch to margin
Ctrl+Enter: Quick insert comments
Shift+Enter: Quick insert Class name

Author:
Kevin Papst
http://www.kevinpapst.de/

Initially written for the BIGACE CMS:
http://www.bigace.de/

Feel free to drop a Comment :)

Install:
- Download the zip file
- Unzip it in your markItUp! sets folder
- Modify your JS link to point at this set.js
- Modify your CSS link to point at this style.css

