Markup language: 
None

Description:
Add a button to open a 27 color palette inspired by the Tango Desktop Project palette (http://tango.freedesktop.org/).

Install:
- Download the zip file
- Unzip it
- Merge the style.css with your current markItUp! style.css
- Merge the set.js with your current markItUp! set.js
- Place the icon in your markItUp! images folder