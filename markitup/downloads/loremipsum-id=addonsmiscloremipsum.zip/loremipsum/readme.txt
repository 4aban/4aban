Markup language: 
None

Description:
Add a dropdown menu to insert some fake Lorem Ipsum text.

Install:
- Download the zip file
- Unzip it
- Merge the style.css with your current markItUp! style.css
- Merge the set.js with your current markItUp! set.js
- Place the icon in your markItUp! images folder