// ----------------------------------------------------------------------------
// markItUp!
// ----------------------------------------------------------------------------
// Copyright (C) 2008 Jay Salvat
// http://markitup.jaysalvat.com/
// ----------------------------------------------------------------------------
mySettings = {	
	markupSet:  [	
		{	name:'Lorem Ipsum', className:'lorem', dropMenu: [
				{name:'Lorem ipsum...', className:'lorem-special', replaceWith:'Lorem ipsum dolor sit amet, consectetuer adipiscing elit.' },
				{name:'Suspendisse...', className:'lorem-special', replaceWith:'Suspendisse lectus tortor, dignissim sit amet, adipiscing nec, ultricies sed, dolor.' },
				{name:'Maecenas...', className:'lorem-special', replaceWith:'Maecenas ligula massa, varius a, semper congue, euismod non, mi.' },
				{name:'Proin porttitor...', className:'lorem-special', replaceWith:'Proin porttitor, orci nec nonummy molestie, non fermentum diam nisl sit amet erat.' },
				{name:'Duis arcu...', className:'lorem-special', replaceWith:'Duis arcu massa, scelerisque vitae, consequat in, pretium a, enim.' },
				{name:'Long paragraph', replaceWith:'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean ut orci vel massa suscipit pulvinar. Nulla sollicitudin. Fusce varius, ligula non tempus aliquam, nunc turpis ullamcorper nibh, in tempus sapien eros vitae ligula. Pellentesque rhoncus nunc et augue. Integer id felis. Curabitur aliquet pellentesque diam. Integer quis metus vitae elit lobortis egestas. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi vel erat non mauris convallis vehicula. Nulla et sapien. Integer tortor tellus, aliquam faucibus, convallis id, congue eu, quam. Mauris ullamcorper felis vitae erat. Proin feugiat, augue non elementum posuere, metus purus iaculis lectus, et tristique ligula justo vitae magna.' }
			]
		}
	]
}