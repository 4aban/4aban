Markup language: 
BBCode

Description:
Add a 8 color palette to insert [color] tag.

Install:
- Download the zip file
- Unzip it
- Merge the style.css with your current markItUp! style.css
- Merge the set.js with your current markItUp! set.js
- Place the icon in your markItUp! images folder