Markup language: 
Texy

Description:
A basic Texy markup set with Headings, Bold, Italic, Picture, Link, Lists, Quotes and Codes (Inline and Block).

Install:
- Download the zip file
- Unzip it in your markItUp! sets folder
- Modify your JS link to point at this set.js
- Modify your CSS link to point at this style.css
