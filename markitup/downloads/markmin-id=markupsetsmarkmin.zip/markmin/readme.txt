Markup language: 
MarkMin (For web2py applications)
http://web2py.com/examples/static/markmin.html

Description:
A basic MarkMin markup set with Headings, Bold, Italic, Picture, Link, List and Preview button.

Install:
- Download the zip file
- Unzip it in your markItUp! sets folder
- Modify your JS link to point at this set.js
- Modify your CSS link to point at this style.css