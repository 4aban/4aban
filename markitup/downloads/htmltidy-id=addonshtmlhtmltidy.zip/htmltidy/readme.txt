Markup language: 
Html

Description:
Add buttons to check or repair your content in a strict and valid Html with Html Tidy via Ajax and a Php server-side script.

Test it below:
<h1>markItUp! server-side scripts & Ajax</h2>
<h3>markItUp! and Tidy Html</h4>
<p>Here <i>is a <u>piece</i></u> of <b>invalid HTML code</b>!

Install:
- Download the zip file
- Unzip it
- Merge the style.css with your current markItUp! style.css
- Merge the set.js with your current markItUp! set.js
- Place the icon in your markItUp! images folder
- Place Utils folder in your markItUp! folder