Markup language: 
Html

Description:
Add a button to escape any special Html chars from the selection as < >.

Test it below:
<strong>select this "line" and press the button</strong>

Install:
- Download the zip file
- Unzip it
- Merge the style.css with your current markItUp! style.css
- Merge the set.js with your current markItUp! set.js
- Place the icon in your markItUp! images folder