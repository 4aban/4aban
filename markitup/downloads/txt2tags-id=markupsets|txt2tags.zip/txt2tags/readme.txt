Copyright (C) 2009 Florent Gallaire <fgallaire@gmail.com>  
License GNU GPLv3 or any later version.

Copyright (C) 2008 Jay Salvat
MarkItUp!
http://markitup.jaysalvat.com/

Silk icons by Mark James under CC-BY
http://www.famfamfam.com/lab/icons/silk/

Markup language : 
Txt2tags

Web site :
http://txt2tags.org

Code repository :
http://txt2tags.googlecode.com/svn/trunk/extras/markitup

Demo :
http://etxt2tags.appspot.com/

Description :
A basic Txt2tags markup set with Headings, Bold, Italic, Underline, Strike, Picture, Link, Lists, Quote, Code, Raw, Preview button.

Install :
- Download the zip file
- Unzip it in your markItUp! sets folder
- Modify your JS link to point at this set.js
- Modify your CSS link to point at this style.css

