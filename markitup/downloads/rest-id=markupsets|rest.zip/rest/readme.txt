Copyright (C) 2009 Florent Gallaire <fgallaire@gmail.com>  
License GNU GPLv3 or any later version.

Copyright (C) 2008 Jay Salvat
MarkItUp!
http://markitup.jaysalvat.com/

Silk icons by Mark James under license Creative Commons BY
http://www.famfamfam.com/lab/icons/silk/

Markup language : 
ReStructuredText

Web site :
http://docutils.sourceforge.net/rst.html

Code repository :
https://bitbucket.org/fgallaire/rest-markitup

Demo :
http://e-rest.appspot.com

Description :
A basic ReStructuredText markup set with Headings, Bold, Italic, Picture, Link, Lists, Quote, Code, Preview button.

Install:
- Download the zip file
- Unzip it in your markItUp! sets folder
- Modify your JS link to point at this set.js
- Modify your CSS link to point at this style.css
